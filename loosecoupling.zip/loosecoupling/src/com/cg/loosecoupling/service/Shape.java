package com.cg.loosecoupling.service;

public interface Shape {
public void getShape();

}
