package com.cg.loosecoupling.service;

public class Circle implements Shape {

	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("Circle");
	}

}
