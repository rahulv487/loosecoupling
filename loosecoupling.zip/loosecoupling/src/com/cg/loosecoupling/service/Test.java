package com.cg.loosecoupling.service;

import java.util.Scanner;

public class Test {
	
	public static void main(String[] args){
	Scanner s = new Scanner(System.in);
	String a = s.next();
	
	Shape shape = ShapeInfo.showShape(a);
	shape.getShape();
	}
}
