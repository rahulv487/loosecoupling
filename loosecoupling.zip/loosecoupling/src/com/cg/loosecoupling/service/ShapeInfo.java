package com.cg.loosecoupling.service;

public class ShapeInfo {
 public static Shape showShape(String shape){
	 if(shape.equals("cir")){
		 return new Circle();
		 
	 }else if(shape.equals("tran")){
		 return new Tran();
	 }else
		 return null;
 }
}
