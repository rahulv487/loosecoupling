package com.cg.loosecoupling.service;

public class Tran implements Shape{

	@Override
	public void getShape() {
		System.out.println("Triangle");
	}

}
